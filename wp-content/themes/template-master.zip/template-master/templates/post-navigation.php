<div class="post-navigation">

	<?php template_page_navi(); ?>

</div>