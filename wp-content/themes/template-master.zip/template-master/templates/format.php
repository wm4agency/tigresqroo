<?php
/* This theme doesn't use post formats per se but we need this 
to pass the theme check.

We may add better support for post formats in the future.
*/