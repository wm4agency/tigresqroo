<p class="footer-comment-count">
	<?php comments_number( __( '<span>No</span> Comments', 'templatetheme' ), __( '<span>One</span> Comment', 'templatetheme' ), __( '<span>%</span> Comments', 'templatetheme' ) );?>
</p>